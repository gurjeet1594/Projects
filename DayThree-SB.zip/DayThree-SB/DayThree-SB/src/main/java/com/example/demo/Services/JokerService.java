package com.example.demo.Services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.demo.Data.Joker;

@Service
	public class JokerService {
	//ArrayList<Joker> records = new ArrayList<>();
@Autowired
	private JokerRepo repo;

	public ArrayList<Joker> showall() {
		return repo.findAll();
	}

	public Joker findById(int Y) {
			return  repo.findById(Y);
	}
	

	public ArrayList<Joker> findByname(String X) {
		return repo.findByname(X);	
	}
	
	public ArrayList<Joker> findByrating(int rating) {
		return repo.findByrating(rating);	
	}
	
	public ArrayList<Joker> findByRatingGreaterThan(int rating) {
		return repo.findByRatingGreaterThan(rating);	
	}
	
	public ArrayList<Joker> findByRatingBetween(int rate1 , int rate2) {
		return repo.findByRatingBetween(rate1,rate2);	
	}
	
	
	public String Savedata(Joker ref) {
		repo.save(ref);
		return "record saved";
	}
	
	
   	public String Savedata(int id,String name, String comment, int rating) {
				Joker ref=new Joker();
				ref.setID(id);
				ref.setName(name);
				ref.setComment(comment);
				ref.setRating(rating);
				repo.save(ref);
				return "record saved";
}

   	public String deleteRecord(int G) {
		Joker T = findById(G);
		if(T == null) {
			return "Record not found";
		}
		 repo.deleteById(G);
		 return "record deleted";
	}
   	
   	public String updateRecord(int R1,String F, String X, int H) {
		Joker z = findById(R1);
		if(z == null) {
			return "Not found";
		}
		if(z.getID()==R1) {
		repo.flush();
		z.setName(F);
		z.setComment(X);
		z.setRating(H);
		repo.save(z);
		}
		
		return "Records updated";
	}
}
