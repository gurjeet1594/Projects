﻿package com.qa.javaAssessment;

import java.util.Arrays;

public class Assessment {
	public static void main(String [] args) {
		Assessment assessment = new Assessment();
	assessment.multChar("Hello");
	assessment.getBert("HelloBert");
	assessment.evenlySpaced(4,6,8);
	assessment.nMid("Chocolate", 3);
	assessment.superBlock("aabbbbbccee");
	assessment.amISearch("I am goint to amsterdam,Am i","am");
	assessment.fizzBuzz(6);
	}

	public String multChar(String input) {
		String word = "";
		for (int i = 0; i< input.length(); i++) {
			word += input.substring(i, i+1);
			word += input.substring(i, i+1);
			word += input.substring(i, i+1);
		}
		return word;
	}
	

	public String getBert(String input) {
		
      String W = "",Alpha;
      int i = input.length()-1;
    	  for(;i>=0;i--){
    		  Alpha = input.substring(i,i+1);
    		  if(Alpha.equals("")) {
    			  System.out.print(W);
    			  W = "";
    			  }
    		  else {
    			  W = Alpha ;
    			  W.compareToIgnoreCase("bert");
    			  
    		  }
    	  }
		return W;
	
	}


	public boolean evenlySpaced(int a, int b, int c) {

		    int large = Math.max(a, Math.max(b, c));
		    int small = Math.min(a, Math.min(b, c));
		    int medium = (a + b + c) - (large + small);

		    return ((large - medium) == (medium - small));
		}
	
	

	public String nMid(String input, int a) {


		StringBuilder w = new StringBuilder(input);
		int len = input.length();
		int mid;
		if (a>1) {
		 mid = len/3;
		}else {
			mid = len/2;
		}
		for (int i = 0; i <a;i++) {
			w.deleteCharAt(mid);	
		}	
		return w.toString();
	}


	public int superBlock(String input) {
		
		int Block = 0;
		  int x = 1;
		  if (input.length() == 0) 
		  { 
		   Block = 0;
		  } else if (input.length() == 1)
		  { 
		   Block = 1;
		  } else {
		   for (int i = 0; i < input.length() - 1; i++)
		   { 
		    if ((input.length() == 2) && (input.charAt(i) != input.charAt(i + 1)))
		    {
		     Block = 1; 
		    } else if ((input.length() == 3) && (input.charAt(i) != input.charAt(i + 1)))
		    {
		     Block = 1; 
		    } else if (input.charAt(i) == input.charAt(i + 1)) {
		     x = x + 1;
		     if (x > Block) 
		     {
		      Block = x; 
		     }
		    } else x = 1;
		   }
		  }
		  return Block;
		 }
		

	public int amISearch(String arg1,String lookfor) {
		int count = 0;
		String alpha;
		int i;
		for(i=0;i<arg1.length();i++){
			alpha = arg1.substring(i,i+1);
			if(alpha.equals(lookfor.substring(0,1))){
				if(arg1.substring(i,i+lookfor.length()).equals(lookfor)){
					count++;
					i+=lookfor.length()-1;
				}
			
			}
		}
		return count;
	}
	
	
	public String fizzBuzz(int arg1) {
		String a = null;
		if((arg1%3==0) && (arg1%5==0)) {
			
		 a ="fizzbuzz";
		}

		else if (arg1%3==0) {
			 a ="fizz";
		}
		
		else if  (arg1%5==0) {
			 a ="buzz";
		}
	  return a ;
	}
	
	
	//Given a string split the string into the individual numbers present
	//then add each digit of each number to get a final value for each number
	// String example = "55 72 86"
	//
	// "55" will = the integer 10
	// "72" will = the integer 9
	// "86" will = the integer 14
	//
	// You then need to return the highest vale
	//
	//largest("55 72 86") ==> 14
	//largest("15 72 80 164") ==> 11
	//largest("555 72 86 45 10") ==> 15
	
	public int largest(String arg1) {
		return -1;
	}
	}
