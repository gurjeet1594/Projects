package com.nationwide.calculator;
public class DigitToWordArray {
 
   public static void main(String[] args) {
	System.out.println(numberToWord(4560));
   }
   
 
   private static String numberToWord(int number) {
        
        String Result = "";
        String ones[] = { "", "one", "two", "three", "four", "five", "six", 
                      "seven", "eight", "nine", "ten", "eleven", "twelve",
                      "thirteen", "fourteen", "fifteen", "sixteen", "seventeen", 
                      "eighteen", "nineteen" };
        String Ty[] = { "","", "twenty", "thirty", "forty", "fifty",
                      "sixty", "seventy", "eighty", "ninety" };
 

	if (number>= 1000) {
	    Result += ones[number / 1000] + " thousand ";
	    number %= 1000;
	}

	if (number>=100)  {
		Result += ones[number / 100] + " hundred ";
	     number %= 100;
	}
 

	 if (number>=20) { 
          Result += Ty[number/10];
          number=number-(number/10*10);
	 }
            
	 if(number>=1) {
		 Result+=ones[number];
	 }
	  return Result;
   }
}