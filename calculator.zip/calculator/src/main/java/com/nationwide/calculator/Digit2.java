package com.nationwide.calculator;
import java.awt.*;
import java.awt.event.*;

public class Digit2 {
public static void main (String [] args) {
		
		Frame F = new Frame("Digit2-QA");
		Panel P1 = new Panel();
		Panel P2 = new Panel();
	
		
		TextField Txt1;
		TextField Txt2;
		Button Convert;
		
	
		Txt1 = new TextField(20);
		Txt2 = new TextField(20);
		
		Convert = new Button("Convert");
		
		P1.add(Txt1);
		P2.add(Txt2);
		P1.add(Convert);
		
		Eventhandler2 event = new Eventhandler2(Txt1);
		
		F.add(P1,BorderLayout.NORTH);
		F.add(P2,BorderLayout.CENTER);
		F.setSize(400,400);
		F.setVisible(true);
		
}





}