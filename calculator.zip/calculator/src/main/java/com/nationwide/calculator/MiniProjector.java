package com.nationwide.calculator;
import java.awt.*;
import java.awt.event.*;
	public class MiniProjector {

	public static void main (String [] args) {
		
		Frame F = new Frame("3D-Calculator");
		Panel P1 = new Panel();
		Panel P2 = new Panel();
		GridLayout GL = new GridLayout(4,4);
		P2.setLayout(GL);
		
		TextField Screen;
		TextField Screen1;
		TextField Screen3;
		Button B0,B1,B2,B3,B4,B5,B6,B7,B8,B9,B10,B11,B12,B13,B14,B15;
		Button Add,Sub,Mul,Div,Clear,Equal;
		Screen = new TextField(20);
		
		
		B0 = new Button("0");
		B1 = new Button("1");
		B2 = new Button("2");
		B3 = new Button("+");
		B4 = new Button("3");
		B5 = new Button("4");
		B6 = new Button("5");
		B7 = new Button("-");
		B8 = new Button("6");
		B9 = new Button("7");
		B10 = new Button("8");
		B11= new Button("/");
		B12= new Button("9");
		B13= new Button("C");
		B14= new Button("=");
		B15= new Button("X");
		
		Equal = new Button("=");
		
		P1.add(Screen);
		P2.add(B0);
		P2.add(B1);
		P2.add(B2);
		P2.add(B3);
		P2.add(B4);
		P2.add(B5);
		P2.add(B6);
		P2.add(B7);
		P2.add(B8);
		P2.add(B9);
		P2.add(B10);
		P2.add(B11);
		P2.add(B12);
		P2.add(B13);
		P2.add(B14);
		P2.add(B15);
		
		
		//AddEventhandler plus = new AddEventhandler(T1,T2,T3,error);
		//SubEventhandler sub = new SubEventhandler(T1,T2,T3,error);
		//MultiplyEventhandler multiply= new MultiplyEventhandler(T1,T2,T3,error);
		//DivideEventhandler divide = new DivideEventhandler(T1,T2,T3,error);
		Eventhandler1 event = new Eventhandler1(Screen);
		
		B0.addActionListener(event);
        B1.addActionListener(event);
		B2.addActionListener(event);
		B3.addActionListener(event);
		B4.addActionListener(event);
		B5.addActionListener(event);
		B6.addActionListener(event);
		B7.addActionListener(event);
		B8.addActionListener(event);
		B9.addActionListener(event);
		B10.addActionListener(event);
		B11.addActionListener(event);
		B12.addActionListener(event);
		B13.addActionListener(event);
		B14.addActionListener(event);
	    B15.addActionListener(event);
		
		BorderLayout BL =new BorderLayout();
		
	    F.add(P1,BorderLayout.NORTH);
	    F.add(P2,BorderLayout.CENTER);
	    
		F.setSize(400,400);
		F.setVisible(true);
		
	}
	}

