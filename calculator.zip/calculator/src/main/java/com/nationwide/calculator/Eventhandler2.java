package com.nationwide.calculator;

import java.awt.*;
import java.awt.event.*;

	public class Eventhandler2 implements ActionListener{
		TextField Txt1;
		Label error;
		Button btn;
		
	public Eventhandler2(TextField T1) {
		Txt1= T1;
		}
	
	public void actionPerformed(ActionEvent e) {
			// TODO Auto-generated method stub
			
		}

		
		

	
	
	
}