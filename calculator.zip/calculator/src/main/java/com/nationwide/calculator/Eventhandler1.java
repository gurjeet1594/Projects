package com.nationwide.calculator;
import java.awt.*;
import java.awt.event.*;

public class Eventhandler1 implements ActionListener{
	TextField Txt1;
	Label error;
	Button btn;
	
public Eventhandler1 (TextField T1) {
		Txt1 = T1;
		
}
public void actionPerformed(ActionEvent AE) {
    int A,B,C;
    String no1, no2, result;
    A=B=C=0;
    Button Btn;
    Btn=(Button)AE.getSource();
    String sign = Btn.getLabel();
    Txt1.setText(Txt1.getText()+sign);
    
    
    
try {
	A=Integer.parseInt(Txt1.getText());
	   B=Integer.parseInt(Txt1.getText());
	

    
    if(sign.equals("="))
    {
    	
    }
  
   if(sign.equals("+"))
    {
	   
	   C = A+B;
    }
   
    
   // if(sign.contentEquals("-"))
   // {
   // 	C=A-B;
  //  }
    
  //  if(sign.contentEquals("X"))
   // {
    	
    	
    //	C=A*B;
   // }
    
  //  if(sign.contentEquals("/"))
  //  {
  //  	C=A/B;
  //  }
  
    
 
		Txt1.setText(Integer.toString(C));
}
		catch(NumberFormatException X) {
		
		error.setText("Digits only,Please");
	}
    
    
   
}
}
