package com.example.demo.Controllers;

import java.util.ArrayList;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
//import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.Data.Joker;
import com.example.demo.Services.JokerService;


@RestController
@CrossOrigin("*")
public class JokerController {

		@Autowired
		private JokerService service;
		
		@GetMapping("/showall")
		public ArrayList<Joker> showall() {
			return service.showall();
		}
		
		@GetMapping("/showid/{R}")
		public Joker showid(@PathVariable int R) {
			return service.findById(R);
		}
		@GetMapping("/findbyname/{N}")
		public ArrayList<Joker> showRegno(@PathVariable String N) {
			return service.findByname(N);
		}
		
		@GetMapping("/findbyrating/{G}")
		public ArrayList<Joker> showRating(@PathVariable int G) {
			return service.findByrating(G);
		}
		
		
		@GetMapping("/findByRatingGreaterThan/{rating}")
		public ArrayList<Joker> filterByRatingGreaterThan(@PathVariable int rating) {
			return service.findByRatingGreaterThan(rating);
		}
		@GetMapping("/findByRatingBetween/{rating1}/{rating2}")
		public ArrayList<Joker> filterByRatingBetween(@PathVariable int rating1,@PathVariable int rating2) {
			return service.findByRatingBetween(rating1,rating2);
		}
		
//		@PostMapping("/Saves")
//		public String Savedata(@RequestBody Joker ref) { 
//			if(ref.getID()==15) {
//				return "Sorry";
//			}
//			else { service.Savedata(ref);}
//			return "record saved";
//		}

		
		@PostMapping("/save3")
		public String Savedata3(@RequestBody Joker J) {
			service.Savedata(J);
			return "record saved";
		}

		@RequestMapping(method=RequestMethod.DELETE,value = "/deleteRecord/{G}")
		public String deleteRecord(@PathVariable int G) {
			return service.deleteRecord(G);
		}
		
		@RequestMapping(method=RequestMethod.POST,value = "/updateRecord/{R1}/{F}/{X}/{H}")
		public String updateRecord(@PathVariable int R1,@PathVariable String F, @PathVariable String X,@PathVariable int H) {
			return service.updateRecord(R1,F,X,H);
		}

		
}