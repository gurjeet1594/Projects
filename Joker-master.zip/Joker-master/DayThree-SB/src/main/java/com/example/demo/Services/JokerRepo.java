package com.example.demo.Services;

import java.util.ArrayList;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.Data.Joker;

@Repository
public interface JokerRepo extends JpaRepository<Joker,Integer>{
	public ArrayList<Joker> findAll();
	public Joker findById(int Y);
	public ArrayList<Joker> findByname(String X);
	public ArrayList<Joker> findByrating(String Y);
	public ArrayList<Joker> findByrating(int rating);
	public ArrayList<Joker> findByRatingGreaterThan(int rating);
	public ArrayList<Joker> findByRatingBetween(int rate1,int rate2);
  
  	
	
}
